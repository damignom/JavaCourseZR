package intensive.Homework5.Strategy;

interface PaymentStrategy {
    void pay(int amount);
}
