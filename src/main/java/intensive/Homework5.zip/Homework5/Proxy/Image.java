package intensive.Homework5.Proxy;

public interface Image {
    void display();
}
