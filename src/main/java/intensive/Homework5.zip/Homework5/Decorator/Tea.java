package intensive.Homework5.Decorator;

interface Tea {
    String getDescription();
    int getCost();
}
